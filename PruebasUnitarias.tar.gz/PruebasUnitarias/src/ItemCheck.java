import java.util.Scanner;
import java.util.InputMismatchException;
import java.lang.NullPointerException;
import java.io.IOException;

/**
* Class that allows to check that the Item class has been created right!!
* This class has several comments that we think that they will be useful for our students. Please, read all the comments (they are in Spanish).
* @author David Garc�a Sol�rzano
* @version 1.0
*/
public class ItemCheck{

	public static void main(String[] args){
		Item item = null;
		boolean exit = false;
		int operation = 0;
				
		do{
			System.out.println("\n*********Item test***********");
			System.out.println("\n\t1. Create a default item.");
			System.out.println("\n\n\t2. Get item's name.");
			System.out.println("\n\n\t3. Set item's name.");
			System.out.println("\n\n\t4. Current getter.");
			System.out.println("\n\n\t5. Set item's stock.");
			System.out.println("\n\n\t6. Decrease stock 1 unit.");						
			System.out.println("\n\n\t7. Exit.");
			System.out.println("*****************************");
			Scanner in = new Scanner(System.in);
			try{//Como se van a capturar errores, necesitamos poner el c�digo que puede lanzar excepciones dentro de "try" y gestionar los posibles errores dentro de "catch"
				operation = in.nextInt();
			
				switch(operation){
					case 1:
							//Crear item con los valores por defecto
							item = new Item();
							System.out.println(item+" has been created!");
							break;
					case 2:
							//Obtener el valor del name
							System.out.println("Item's name is "+item.getName());
							break;
					case 3:
							//Asignar el nombre del producto
							System.out.println("Please, type the item's new name:");	
							in.nextLine(); //bug: to capture the "extra enter"							
							String name = in.nextLine();;
							item.setName(name);						
							break;
					case 4:
							//Cambia getImageSrc por getNetPrice, getTax, getKcal y getStock para probar los diferentes getters 
							System.out.println("Item's imageSrc is  "+item.getImageSrc());
							break;
					case 5:
							//Asignar el n�mero de stock que tenemos para el �tem/producto.
							System.out.println("Type item's stock");
							int value = in.nextInt();
							if(item.setStock(value)) System.out.println("The item's stock is "+item.getStock());
							else throw new Exception("Stock cannot be a negative value!!");
							//////////////item.stock = 83;
							break;
					case 6: 
							//Decrementa en una unidad el valor del stock
							if(item.decrease1Stock())	System.out.println("The new stock is "+item.getStock());
							else throw new Exception("This item is sold out!! You cannot decrease 1 unit.");
							break;
					case 7: 
							//Salir del programa.
							exit = true;
							in.close();
							break;
				}
			}catch(InputMismatchException e1){//Error que se lanza si el valor, en este caso introducido por teclado, no es un n�mero.
				System.err.println("[ERROR] You have to enter a number!!");
			}catch(NullPointerException e2){//Error que se lanza cuando se intenta acceder a un objeto que no ha sido instanciado (i.e. no se ha hecho previamente "new").
				System.err.println("[ERROR] You have to create an item first!!");
			}catch(Exception e3){ //Gesti�n del error lanzado por el constructor de la clase Item que usa los diferentes setters num�ricos, los cuales pueden lanzar una excepci�n (Ejercicio 2)
				System.err.println("[ERROR] "+e3.getMessage());
			}
			
			if(operation!=7){				
				System.out.println("\nPress Enter to continue...");
				try{
					/*
						Como el m�todo "read" puede lanzar una excepci�n (su implementaci�n tiene un "throws IOException" (IOException es un caso particular de Exception), ponemos la l�nea dentro de try
						y gestionamos el error dentro del catch. Si en el catch, en vez de IOException ponemos Exception, tambi�n funcionar� por el concepto de herencia (lo veremos m�s adelante en los apuntes).
					*/
					System.in.read();
				}catch(IOException enterError){
					System.err.println("[ERROR] Keyboard input throwed an exception!!");
				}			
			}			
			
		}while(!exit);
		System.out.println("Bye!!");
	}	
}