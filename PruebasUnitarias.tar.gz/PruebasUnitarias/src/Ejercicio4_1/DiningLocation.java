package Ejercicio4_1;

public enum DiningLocation {
	EATIN, TAKEAWAY
}
