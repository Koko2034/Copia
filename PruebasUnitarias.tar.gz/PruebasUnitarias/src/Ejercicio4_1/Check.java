package Ejercicio4_1;
/**
 * This class is used to test the Exercise 2 of the PAC/PEC 3.
 * 
 * @author David Garc�a Sol�rzano
 * @version 1.0
 * 
 */

public class Check {

	public Check() {
		
	}

	public static void main(String[] args) {		
		Item item1 = null, item2 = null, item3 = null;
		
		try{
			item1 = new Item("Big Pac","./bigpac.jpg",2.69,0.21,365,250);		
			item2 = new Item("Uocpper","./uocpper.jpg",2.27,0.21,250,250);
			item3 = new Item("Fries","./fries.jpg",1.24,0.21,100,250);
		}catch(ItemException ie){
			ie.printStackTrace();
		}
		
		Order order1 = new Order();
		
		//Pedido vacio
		System.out.println(order1);
		
		try {
			order1.addItem(item1);
			order1.addItem(item2);
			order1.addItem(item3);
			System.out.println(System.lineSeparator());
			System.out.println("_____________________________");
			System.out.println(order1);
			System.out.println("_____________________________"); //Hasta aqui es el ejemplo del enunciado.
			System.out.println(System.lineSeparator());
			
			
			//order1.removeItem(3); //Si descomentas esta linea deberia saltarte una Excepcion
			//order1.removeItem(1); //Elimina la "Uocpper".
			System.out.println(order1);
			
			order1.addItem(item1); 
			order1.addItem(item1);
			order1.addItem(item1);
			order1.addItem(item1);
			order1.addItem(item1);
			order1.addItem(item1);
			order1.addItem(item1);
			order1.addItem(item1);
			order1.addItem(item1);
			order1.addItem(item1);
			order1.addItem(item1);
			order1.addItem(item1);
			order1.addItem(item1); //Veras que con esta linea, si no descomentas la linea 43, nos pasamos de 15 items.
			System.out.println(order1);
			
			Order order2 = new Order();
			System.out.println("\n"+order2.getId());
			//si descomentas la linea de debajo, �que valor crees que devolvera?
			//System.out.println(order1.getId());
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}