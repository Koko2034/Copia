package Ejercicio4_1;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;



public class ItemExceptionTest {

	@Test
	public void testItemException() {
		
		ItemException itemException = new ItemException();
		
		Assert.assertEquals(null, itemException.getMessage());
	}

	@Test
	public void testItemExceptionString() {
		
		String msg = "Error cometido";
		
		ItemException itemException = new ItemException(msg);
		
		Assert.assertEquals(msg, itemException.getMessage());
	}

}
