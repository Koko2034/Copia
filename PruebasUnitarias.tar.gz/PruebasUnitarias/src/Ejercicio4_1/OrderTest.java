package Ejercicio4_1;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;





public class OrderTest {

	Order order;
	Item item;
	
	@Before
	public void inicializate() throws Exception{
		
		order = new Order();
		item = new Item("Big Pac","./bigpac.jpg",2.69,0.21,365,250);
	}
	@Rule
	
	public ExpectedException thrown = ExpectedException.none();
	
	@Test
	public void testOrder() throws Exception{
		
		
		Assert.assertEquals(DiningLocation.EATIN, order.getDiningLocation());
		Assert.assertEquals(0,order.getItems().size());
		
		order.setId(0);
		Order order2 = new  Order();
		
		Assert.assertEquals(1,order2.getId());
	}

	@Test
	public void testGetId() throws Exception{
		
		order.setId(1);
		
		Assert.assertEquals(1, order.getId());
	}

	@Test
	public void testSetId() throws Exception{
		
		order.setId(8);
		
		Assert.assertEquals(8,order.getId());
	}

	@Test
	public void testGetDiningLocation() throws Exception{
		
		Assert.assertEquals(DiningLocation.EATIN, order.getDiningLocation());
	}

	@Test
	public void testSetDiningLocation() throws Exception{
		
		order.setDiningLocation(DiningLocation.TAKEAWAY);
		
		Assert.assertEquals(DiningLocation.TAKEAWAY, order.getDiningLocation());
		
		order.setDiningLocation(DiningLocation.EATIN);
		
		Assert.assertEquals(DiningLocation.EATIN, order.getDiningLocation());
	}

	
	@Test
	public void testGetItems() throws Exception{
		
		List<Item> items = new ArrayList<Item>();
		items.add(item);
	
		order.addItem(item);
		
		Assert.assertTrue(order.getItems().equals(items));
		
	}
	@Test
	public void testSetItems() throws Exception {
		
		List<Item> items = new ArrayList<Item>();
		items.add(item);
		items.add(item);
		
		order.setItems(items);
		
		Assert.assertTrue(order.getItems().equals(items));
	}

	@Test
	public void testAddItem() throws Exception{

		List<Item> items = new ArrayList<Item>();
		int pos = order.getItems().size();
		
		order.addItem(item);
		
		Assert.assertEquals(item, order.getItems().get(pos));
	}

	@Test
	public void testRemoveItem() throws Exception{
		
		int pos = order.getItems().size();
		order.addItem(item);
		int code = order.getItems().get(order.getItems().size()-1).hashCode();
		
		order.removeItem(pos);
		boolean control = false;
		for(int i=0;i<order.getItems().size();i++){
			control = order.getItems().get(i).hashCode() == code ? true:false;
		}
		
		assertFalse(control);
	}

	@Test
	public void testGetTotalGrossCost() throws Exception{
		
		double coste =0;
		coste+=item.getGrossPrice();
		coste+=item.getGrossPrice();
		order.addItem(item);
		order.addItem(item);
		
		double totalGrossCost = order.getTotalGrossCost();
		
		Assert.assertEquals(coste, totalGrossCost,1e-15);
	}

	@Test
	public void testGetTotalNetCost() throws Exception{
		
		double coste =0;
		coste+=item.getNetPrice();
		coste+=item.getNetPrice();
		order.addItem(item);
		order.addItem(item);
		
		double totalNetCost = order.getTotalNetCost();
		
		Assert.assertEquals(coste, totalNetCost,1e-15);
	}

	@Test
	public void testGetTotalTaxesCost() throws Exception{
		
		double coste =0;
		Item item = new Item("Big Pac","./bigpac.jpg",2.69,0.21,365,250);
		coste+=item.getGrossPrice()-item.getNetPrice();
		coste+=item.getGrossPrice()-item.getNetPrice();
		order.addItem(item);
		order.addItem(item);
		
		double totalTaxesCost = order.getTotalTaxesCost();
		
		Assert.assertEquals(coste, totalTaxesCost,1e-15);
	}

	@Test
	public void testToString() throws Exception{
		
		order.addItem(item);
		
		String namePrice ="Dining location: EATIN\n" + 
				"__________________________\n" + 
				"\n" + 
				"Big Pac......3,25 �\n" + 
				"__________________________\n" + 
				"\n" + 
				"TOTAL: 3,25 �\n" + 
				"Taxes: 0,56 �\n" + 
				"__________________________\n";
		
		Assert.assertEquals(namePrice, order.toString());
	}

}
