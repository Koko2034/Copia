package Ejercicio3_2;
import java.text.DecimalFormat;

/**
 * This class represents an UocDonald's order.
 * 
 * @author David Garc�a Sol�rzano
 * @version 1.0
 * 
 */

public class Order {
	
	private static int id = 0;
	private DiningLocation diningLocation;
	private Item[] items;
	
	
	/**
	  * Default constructor which sets id++, diningLocation equals to EATIN and set items with 15 positions.
	 *	   
	 */
	public Order() {
		increase1Id();
		diningLocation = DiningLocation.EATIN;
		items = new Item[15];
	}


	/**
	 * Returns the order's id.
	 * 
	 * @return Order's number/id.
	 */
	public int getId() {
		return id;
	}


	/**
	 * Sets a new value for the Order's id.
	 * 
	 * @param id New value for the private field "id".
	 */
	public void setId(int id) {
		Order.id = id;
	}


	/**
	 * Returns where the customer will eat her order.
	 * 
	 * @return Dining location's value.
	 */
	public DiningLocation getDiningLocation() {
		return diningLocation;
	}


	/**
	 * Sets where the customer will eat her order.
	 * 
	 * @param diningLocation Location/Place where the customer will eat her order.
	 */
	public void setDiningLocation(DiningLocation diningLocation) {
		this.diningLocation = diningLocation;
	}

	
	/**
	 * Increases 1 unit the value of the private field "id".
	 */
	private void increase1Id(){
		setId(getId()+1); //tambien valdria "id++", pero usando el getter y setter se mejora el mantenimiento ante posibles cambios.
	}
	
	/**
	 * Returns the whole array of items.
	 * 
	 * @return The private field "items".
	 */
	public Item[] getItems() {
		return items;
	}


	/**
	 * Replaces the whole array of items.
	 *	 
	 * @param items New array of items.
	 */
	public void setItems(Item[] items) {
		this.items = items;
	}
	
	/**
	 * Adds a new item to the first null position of the array "items".
	 * 
	 * @param item New item to add.
	 * @throws Exception When more than 15 items are added.
	 */
	public void addItem(Item item) throws Exception{
		boolean found = false;
		for(int i = 0; !found && i<items.length; i++){
			if(items[i]==null){
				items[i] = item;
				found = true;				
			}
		}
		
		if(!found) throw new Exception("An order cannot have more than 15 items!!");
	}
	
	/**
	 * Removes the item in the position "index" of the array "items". It sets "null" that position.
	 * 
	 * @param index Position where the item we want to remove is.
	 * @throws Exception When the position is "null" before removing or the index is incorrect.
	 */
	public void removeItem(int index) throws Exception{
		if(index<0 || index>14){
			throw new Exception("The index is incorrect. The index must be in the range of [0,14]");
		}else{
			if(items[index]==null){
				throw new Exception("The item that you want to remove does not exist in the order!!");
			}else{
				items[index] = null;
			}
		}		
	}
	
	/**
	  * This method adds the gross price of all the items of the order together.
	 * 
	 * @return The sum in euros of the gross price of the order's items.  
	 */
	public double getTotalGrossCost(){
		double total = 0;
		
		for(Item item : items){
			total += (item!=null)?item.getGrossPrice():0;
		}
		
		return total;
		
	}
	
	/**
	  * This method adds the net price of all the items of the order together.
	 * 
	 * @return The sum in euros of the net price of the order's items.  
	 */
	public double getTotalNetCost(){
		double total = 0;
		
		for(Item item : items){
			total += (item!=null)?item.getNetPrice():0;
		}
		
		return total;
		
	}

	/**
	 * This method adds the difference between the gross price and the net price of all the items of the order together.
	 * 
	 * @return The sum in euros of the taxes of the order's items.  
	 */
	public double getTotalTaxesCost(){
		double total = 0;
		
		for(Item item : items){
			total += (item!=null)?(item.getGrossPrice()-item.getNetPrice()):0;
		}
		
		return total;
	}
	
	
	/**
	 * This method overrides Object's toString.
	 * 
	 * @return String with the Order's id, the list of the items with the format "name......grosPrice �", and the total gross cost and total taxes cost.
	 */
	@Override
	public String toString(){
		DecimalFormat df = new DecimalFormat("0.00");
		StringBuilder text = new StringBuilder();
			
		text.append("Dinning location: "+getDiningLocation()+"");
		text.append("\n__________________________\n");
		
		for(int i = 0;i<items.length;i++){
			if(items[i]!=null){
				text.append("\n"+items[i]); //aprovechamos el m�todo toString de Item que ya devuelve el String en el formato que necesitamos.
			}
		}
		
		text.append("\n__________________________\n");
			
		text.append("\nTOTAL: "+df.format(getTotalGrossCost())+" �");
		text.append("\nTaxes: "+df.format(getTotalTaxesCost())+" �");
		text.append("\n__________________________\n");
		
		return text.toString();		
	}
}
