package Ejercicio3_2;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;



public class ItemTest {

	Item item;
	
	@Before
	public void inicializate() throws Exception{
		item = new Item();
	}
@Rule
	
	public ExpectedException thrown = ExpectedException.none();

	@Test
	public void testItem()  throws Exception {
		
		Assert.assertEquals("Dummy", item.getName());
		Assert.assertEquals("./", item.getImageSrc());
		Assert.assertEquals(0.1, item.getNetPrice(),1e-15);
		Assert.assertEquals(0, item.getTax(),1e-15);
		Assert.assertEquals(1, item.getKcal(),1e-15);
		Assert.assertEquals(0, item.getStock());
	}

	@Test
	public void testItemStringStringDoubleDoubleDoubleInt() throws Exception {
		
		Item item = new Item("Javier", "./image/",20,0.21,15,100);
		
		Assert.assertEquals("Javier", item.getName());
		Assert.assertEquals("./image/", item.getImageSrc());
		Assert.assertEquals(20, item.getNetPrice(),1e-15);
		Assert.assertEquals(0.21, item.getTax(),1e-15);
		Assert.assertEquals(15, item.getKcal(),1e-15);
		Assert.assertEquals(100, item.getStock());
	}

	@Test
	public void testGetName()  throws Exception{
		
		Assert.assertEquals(item.getName(), "Dummy");
	}

	@Test
	public void testSetName()  throws Exception{
		
		String name = "Javier";
		item.setName(name);
		
		Assert.assertEquals(name, item.getName());
	    
	}
	@Test
	public void testSetNameMore() throws Exception{
		
		thrown.expectMessage("The name cannot be longer than 15 characters!!");
	    item.setName("Manolo Cabeza Bolo");
	}

	@Test
	public void testGetImageSrc()  throws Exception{
		
		Assert.assertEquals(item.getImageSrc(), "./");
	
	}

	@Test
	public void testSetImageSrc()  throws Exception{
		
		String imageSrc = "./image";
		
		item.setImageSrc(imageSrc);
		
		Assert.assertEquals(imageSrc, item.getImageSrc());
	}

	@Test
	public void testGetNetPrice()  throws Exception{
		
		Assert.assertEquals(item.getNetPrice(), 0.1,1e-15);
	}

	@Test
	public void testSetNetPrice()  throws Exception{
		
		double netPrice = 0.5;
		
		item.setNetPrice(netPrice);
		
		Assert.assertEquals(netPrice, item.getNetPrice(),1e-15);
		
	}
	
	@Test
	public void testSetNetPriceLess() throws Exception{
		
		thrown.expectMessage("Net price cannot be a negative value!!");
		
	    item.setNetPrice(-11);
	}

	@Test
	public void testGetTax()  throws Exception{
		
		Assert.assertEquals(item.getTax(), 0,1e-15);
	}

	@Test
	public void testSetTax()  throws Exception{
		
		double tax = 0.5;
		
		item.setTax(tax);
		
		Assert.assertEquals(tax, item.getTax(),1e-15);
			
	}
	
	@Test
	public void testSetTaxLess() throws Exception{
		
		thrown.expectMessage("Tax cannot be a negative value!!");
	    
		item.setTax(-11);
		
	}

	@Test
	public void testGetKcal()  throws Exception{
		
		Assert.assertEquals(item.getKcal(), 1,1e-15);
	}

	@Test
	public void testSetKcal() throws Exception {
		
		double kcal = 0.5;
		
		item.setKcal(kcal);
		
		Assert.assertEquals(kcal, item.getKcal(),1e-15);
			
		
	}
	
	@Test
	public void testSetKcalLess() throws Exception{
	
		thrown.expectMessage("Kcal cannot be a negative value!!");
		
		item.setKcal(-11);
	}

	@Test
	public void testGetStock() throws Exception {
		
		Assert.assertEquals(item.getStock(), 0);
		
	}

	@Test
	public void testSetStock() throws Exception {
	
		int stock = 4;
		
		item.setStock(stock);
		
		Assert.assertEquals(stock, item.getStock());
	
		
	}
	@Test
	public void testSetStockLess() throws Exception{
		
		thrown.expectMessage("Stock cannot be a negative value!!");
		
		item.setStock(-11);
	}
	@Test
	public void testDecrease1StockSucess() throws Exception{
		
		int units = 100;
		item.setStock(units);
		
		item.decrease1Stock();
		
		Assert.assertEquals(units-1, item.getStock());
	}
	@Test
	public void testDecrease1Stock()  throws Exception{
		
		thrown.expectMessage("This item is sold out!! You cannot decrease 1 unit.");
		item.decrease1Stock();
	}

	@Test
	public void testGetGrossPrice()  throws Exception{
		
		Assert.assertEquals(item.getGrossPrice(),0.1,1e-15);
		
		item.setTax(2);
		double netPrice = ( item.getTax()*item.getNetPrice())+item.getNetPrice();
		
		double itemGrossPrice = item.getGrossPrice();
		
		Assert.assertEquals(itemGrossPrice,netPrice ,1e-15);
	}

	@Test
	public void testToString()  throws Exception{
		
		String name_price ="Dummy......0,10 �";
		
		String text = item.toString();
		
		Assert.assertEquals(name_price, text);
		
		
	}

	

}
