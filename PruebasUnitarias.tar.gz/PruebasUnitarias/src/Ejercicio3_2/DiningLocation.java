package Ejercicio3_2;

public enum DiningLocation {
	EATIN, TAKEAWAY
}
