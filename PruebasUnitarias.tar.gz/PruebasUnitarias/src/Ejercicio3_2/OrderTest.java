package Ejercicio3_2;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;


public class OrderTest {

	Order order;
	Item item1;
	Item item2;
	Item item3;
	
	@Before
	public void inicializate() throws Exception{
		
		order = new Order();
		order.setId(1);
		item1 = new Item("Big Pac","./bigpac.jpg",2.69,0.21,365,250);
		item2 = new Item("Uocpper","./uocpper.jpg",2.27,0.21,250,250);
		item3 = new Item("Fries","./fries.jpg",1.24,0.21,100,250);
	}
	
	@Rule
	
	public ExpectedException thrown = ExpectedException.none();

	@Test
	public void testOrder() throws Exception{
		
		Assert.assertEquals(1,order.getId());
		Assert.assertEquals(DiningLocation.EATIN, order.getDiningLocation());
		Assert.assertEquals(15,order.getItems().length);
	}

	@Test
	public void testGetId() throws Exception{
		
		Assert.assertEquals(1, order.getId());
	}

	@Test
	public void testSetId() throws Exception{
		
		order.setId(8);
		
		Assert.assertEquals(8,order.getId());
	}

	@Test
	public void testGetDiningLocation() throws Exception{
		
		Assert.assertEquals(DiningLocation.EATIN, order.getDiningLocation());
	}

	@Test
	public void testSetDiningLocation() throws Exception{
		
		order.setDiningLocation(DiningLocation.TAKEAWAY);
		
		Assert.assertEquals(DiningLocation.TAKEAWAY, order.getDiningLocation());
		
		order.setDiningLocation(DiningLocation.EATIN);
		
		Assert.assertEquals(DiningLocation.EATIN, order.getDiningLocation());
		
	}

	@Test
	public void testGetItems() throws Exception{
		
		Item[] items = new Item[15];	
		items[0]=item1;
		items[1]=item1;
		order.addItem(item1);
		order.addItem(item1);
		
		assertTrue(order.getItems().equals(0));
		
	}

	@Test
	public void testSetItems() throws Exception{
		
		Item[] items = new Item[15];
		items[0]= item1;
		items[1]= item2;
		items[2]= item3;
		order.addItem(item1);
		order.addItem(item2);
		order.addItem(item3);
		
		order.setItems(items);
		
		Assert.assertArrayEquals(items,order.getItems());
	}

	@Test
	public void testAddItem() throws Exception{
		
		Item[] items = new Item[15];
		items[0]= item1;
		int pos=0;
		boolean control = true;
		
		order.addItem(item1);
		do{
			control = order.getItems()[pos] == item1 ? false: true;
			pos++;
		}while(control);
		
		Assert.assertEquals(item1,order.getItems()[pos-1]);
	}
	
	@Test
	public void testRemoveItemNumberItem() throws Exception{
			
		thrown.expectMessage("The index is incorrect. The index must be in the range of [0,14]");
		order.removeItem(150);
	}
	@Test
	public void testRemoveItemNullItem() throws Exception{
		
		thrown.expectMessage("The item that you want to remove does not exist in the order!!");
		order.removeItem(0);
	}
	@Test
	public void testRemoveItem() throws Exception{
		
		order.addItem(item1);
		order.removeItem(0);

	}
	@Test 
	public void testRemoveItemNumberNegativeItem() throws Exception{
		
		thrown.expectMessage("The index is incorrect. The index must be in the range of [0,14]");
		order.removeItem(-11);
		
	}

	@Test
	public void testGetTotalGrossCost() throws Exception{
		
		double coste =0;
		coste+=item1.getGrossPrice();
		coste+=item1.getGrossPrice();
		order.addItem(item1);
		order.addItem(item1);
		
		double costeOrder = order.getTotalGrossCost();
		
		Assert.assertEquals(coste, costeOrder,1e-15);
		
		
	}
	@Test
	public void testGetTotalGrossCostFree() throws Exception{
		
		order.addItem(item1);
		double totalGrossCot = order.getTotalGrossCost();
		
		assertEquals(3.25, totalGrossCot,1e-2);
	}

	@Test
	public void testGetTotalNetCost() throws Exception{
		
		double coste =0;
		coste+=item1.getNetPrice();
		coste+=item1.getNetPrice();
		order.addItem(item1);
		order.addItem(item1);
		
		double totalNetCost = order.getTotalNetCost();
		
		Assert.assertEquals(coste, totalNetCost,1e-15);
		
	}
	@Test
	public void testGetTotalNetCostFree() throws Exception{
		
		Item item = new Item("Big Pac","./bigpac.jpg",0,0.21,365,250);
		order.addItem(item);
		double totalNetCostFree = order.getTotalNetCost();
		
		assertEquals(0, totalNetCostFree,1e-15);
	}
	@Test
	public void testGetTotalTaxesCostFree() throws Exception{
		
		Item item = new Item("Big Pac","./bigpac.jpg",2.69,0,365,250);
		order.addItem(item);
		double itemTotalTaxesCostFree = item.getGrossPrice()-item.getNetPrice();
		
		double orderTotalTaxesCostFree = order.getTotalTaxesCost();
		
		assertEquals( itemTotalTaxesCostFree, orderTotalTaxesCostFree,1e-15 );
		
	}
	@Test
	public void testGetTotalTaxesCost() throws Exception{
		
		double coste =0;
		coste+=item1.getGrossPrice()-item1.getNetPrice();
		coste+=item1.getGrossPrice()-item1.getNetPrice();
		order.addItem(item1);
		order.addItem(item1);
		
		double totalTaxesCost = order.getTotalTaxesCost();
		
		Assert.assertEquals(coste, totalTaxesCost,1e-15);
	}

	@Test
	public void testToString() throws Exception{
		
		order.addItem(item1);
		String namePrice ="Dinning location: EATIN\n" + 
				"__________________________\n" + 
				"\n" + 
				"Big Pac......3,25 �\n" + 
				"__________________________\n" + 
				"\n" + 
				"TOTAL: 3,25 �\n" + 
				"Taxes: 0,56 �\n" + 
				"__________________________\n";
		
		
		Assert.assertEquals(namePrice, order.toString());
	}

}
