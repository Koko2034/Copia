package Ejercicio4_2;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;



public class ItemTest {

	Item item;
	
	
	@Before
	public void inicializate() throws Exception{
		
	
		item = new Item("Dummy",200,50);
	}
	@Rule
	
	public ExpectedException thrown = ExpectedException.none();

	@Test
	public void testItem() throws Exception{
		
		Assert.assertEquals("Dummy", item.getName());
		Assert.assertEquals(200, item.getKcal(),1e-15);
		Assert.assertEquals(50, item.getStock());
	}

	@Test
	public void testSetName() throws Exception{
		
		String name = "Javier";
		
		item.setName(name);
		
		Assert.assertEquals(name, item.getName());
	}

	@Test
	public void testGetName() throws Exception{
		
		Assert.assertEquals(item.getName(), "Dummy");
	}

	@Test
	public void testSetKcal() throws Exception{
	
		double cal = 1000;
		
		item.setKcal(cal);;
		
		Assert.assertEquals(cal,item.getKcal(),1e-15);
	}

	@Test
	public void testGetKcal() throws Exception{
		Item item = new Item("Dummy",200,50);
		Assert.assertEquals(item.getKcal(), 200,1e-15);
	}

	@Test
	public void testSetStock() throws Exception{
		
		int units = 1000;
		
		item.setStock(units);
		
		Assert.assertEquals(units,item.getStock());
	}

	@Test
	public void testGetStock() throws Exception{
		
		Assert.assertEquals(item.getStock(), 50);
	}

	@Test
	public void testToString() throws Exception{
		
		Item item = new Item("Big Pac",365,52);
		String hcode = Integer.toHexString(item.hashCode());
		String expectedString = "Big Pac (365.0 kcal): 52 : @" + hcode;
		
		assertEquals(expectedString, item.toString());
	
	}
	

	@Test
	public void testCompareToMore() throws Exception{
		
		Item item1 =new Item("Big Pac 500/units",300,500); 	
		Item item2 = new Item("Big Pac 52/units",365,52); 
		
		assertEquals(-1, item1.compareTo(item2));
		
	}
	@Test
	public void testCompareToLess() throws Exception{
		
		Item item1 =new Item("Big Pac 50/units",300,50); 	
		Item item2 = new Item("Big Pac 500/units",365,500); 
		
		assertEquals(1, item1.compareTo(item2));
	}
	@Test
	public void testCompareToMoreKCal() throws Exception{
		
		Item item2 = new Item("Dummy",100,50);
		
		assertEquals(1,item.compareTo(item2));
	}
	@Test
	public void testCompareToLesKCal() throws Exception{
		
		Item item2 = new Item("Dummy",100,50);
		
		assertEquals(-1,item2.compareTo(item));
		
	}

}
