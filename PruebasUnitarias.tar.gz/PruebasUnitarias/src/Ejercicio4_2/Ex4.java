package Ejercicio4_2;

import java.util.ArrayList;
import java.util.Collections;

public class Ex4{
	public static void  main(String[] args){
		ArrayList<Item> items1 = new ArrayList<Item>();

		Item p1 = new Item("Big Pac",365,52);
		Item p2 = new Item("Uocpper",275,36);
		Item p3 = new Item("Long chicken",250,98);
		Item p4 = new Item("Basicburger",175,98);

		//A�adimos elementos a la ArrayList
		items1.add(p1);
		items1.add(p2);
		items1.add(p3);
		
		ArrayList<Item> items2 = (ArrayList<Item>)items1.clone();
		
		System.out.println("The ArrayList \"items1\":");
		
		for (Item itemTmp : items1) {
			System.out.println("\t"+itemTmp);
		}
		
		System.out.println("\nThe ArrayList \"items2\":");
		
		for (Item itemTmp : items2) {
			System.out.println("\t"+itemTmp);
		}
		
		System.out.println("\n***They are identicals!! The same content in the same order, but, what is more, the same references mean the same objects!!***\n\n");
		
		//a�adimos y eliminamos sobre la ArrayList original
		items1.add(p4);
		items1.remove(p2);

		System.out.println("The ArrayList \"items1\" after adding p4 (=Basicburger) to \"items1\" and removing p2 (=Uocpper) to \"items1\":");
		
		//Motramos ambas ArrayList despues de a�adir y eliminar
		for (Item itemTmp : items1) {
			System.out.println("\t"+itemTmp);
		}
		
		System.out.println("\nThe ArrayList \"people2\" has not been updated:");
		for (Item itemTmp : items2) {
			System.out.println("\t"+itemTmp);
		}
		
		System.out.println("\n***items2 is the same ArrayList as before!!***\n\n");
		
		//y la actualizamos
		System.out.println("We get the first element from \"items1\" (i.e. p1 (=Big Pac)) and update it with name = UOC Pac\n\n");
		Item person = items1.get(0);
		person.setName("UOC Pac");

		//Motramos el primer elemento de cada ArrayList 
		System.out.println("Name of the first element from items1: "+items1.get(0).getName());
		System.out.println("Name of the first element from items2: "+items2.get(0).getName());

		System.out.println("\n***The first element from \"people2\" has been updated too! Why?***\n\n");
		
		
		Collections.sort(items1);
		System.out.println("The ArrayList \"items1\" after sorting by id in descendant order:");
		
		for (Item itemTmp : items1) {
			System.out.println("\t"+itemTmp);
		}
		
		System.out.println("\nThe ArrayList \"items2\" has not been sorted:");
		
		for (Item itemTmp : items2) {
			System.out.println("\t"+itemTmp);
		}
	}
}