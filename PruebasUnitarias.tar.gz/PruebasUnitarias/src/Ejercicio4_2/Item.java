package Ejercicio4_2;
public class Item implements Comparable<Item>{
	private String name;
	private double kcal;
	private int stock;
	
	public Item(String name, int kcal, int stock){
		setName(name);
		setKcal(kcal);
		setStock(stock);
	}
	
	public void setName(String name){
		this.name = name;
	}
	
	public String getName(){
		return name;
	}
	
	public void setKcal(double kcal){
		this.kcal = kcal;
	}
	
	public double getKcal(){
		return kcal;
	}
	
	public void setStock(int stock){
		this.stock = stock;
	}
	
	public int getStock(){
		return stock;
	}
	
	@Override
	public String toString(){
		//After the symbol '@', we show the reference of the object in the heap thanks to the use of Object's "hasCode()" method
		return getName()+" ("+getKcal()+" kcal): "+getStock()+" : "+"@" + Integer.toHexString(hashCode());
	}

	@Override
	public int compareTo(Item arg0) {
	
		if(getStock()<arg0.getStock())
			return 1;
		else if(getStock()>arg0.getStock()) 
			return -1;
		else{
			if(getKcal()<arg0.getKcal())
				return -1;
			else
				return 1;
		}
	}
}