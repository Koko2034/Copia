public class Item {

	private String name, imageSrc;
	private double netPrice, tax, kcal;
	private int stock;	
		
		
	public Item() throws Exception{
		this("Dummy", "./",0.1,0,1,0);		
	}
	
	public Item(String name, String imageSrc, double netPrice, double tax, double kcal, int stock) throws Exception{
		setName(name);
		setImageSrc(imageSrc);
		setNetPrice(netPrice);
		setTax(tax);
		setKcal(kcal);
		setStock(stock);	
	}
		
	public String getName() {
		return name;
	}


	public void setName(String name) throws Exception{
		if(name.length()>15){
			throw new Exception("The name cannot be longer than 15 characters!!");
		}
		this.name = name;

	}

	public String getImageSrc() {
		return imageSrc;
	}

	public void setImageSrc(String imageSrc) {
		this.imageSrc = imageSrc;
	}

	public double getNetPrice() {
		return netPrice;
	}

	public void setNetPrice(double netPrice) {
		this.netPrice = netPrice;
	}

	public double getTax() {
		return tax;
	}

	public void setTax(double tax) {
		this.tax = tax;
	}

	public double getKcal() {
		return kcal;
	}

	public void setKcal(double kcal) {
		this.kcal = kcal;
	}

	public int getStock() {
		return stock;
	}

	public boolean setStock(int stock) {
		if(stock<0){
			return false;
		}else{
			this.stock = stock;
			return true;
		}
	}	
	
	public boolean decrease1Stock(){
		if(getStock()-1<0){ //Tambi�n se puede hacer if(stock-1<0){ o if(stock==0) o if(getStock()==0).
			return false;
		}else{
			setStock(getStock()-1);
			return true;
		}
	}
	
	/*
	 * La implementaci�n anterior sigue a raja tabla lo que dice el enunciado. Es decir, es 100% imperativo.
	 * O dicho de otro modo, traslada frase por frase lo que dice el enunciado, sin m�s.
	 * 
	 * Otra forma de implementar decrease1Stock() sac�ndole el m�ximo partido a la implementaci�n de "setStock" ser�a
	 * la que se muestra a continuaci�n, la cual optimiza el c�digo anterior y adem�s hace lo que pide el enunciado: 
	 * 
	 * public boolean decrease1Stock(){
	 * 
	 * 		return setStock(getStock()-1);
	 * 
	 * }
	 * 
	 * Lo que hace esta implementaci�n es centrarlizar la gesti�n de comprobar el signo del valor pasado por par�metros 
	 * (i.e. positivo o negativo) en un �nico m�todo.
	 */
	
	public double getGrossPrice() {
		double tax = getTax();
		if(tax==0)
			return getNetPrice();
		else
			return (getNetPrice()*tax)+getNetPrice();
	}
}