package Ejercicio3_1;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;



public class ItemExceptionTest {

	ItemException itemException;
	
	@Rule
	
	public ExpectedException thrown = ExpectedException.none();

	
	@Test
	public void testItemException() {
		
		ItemException itemException = new ItemException();
		
		Assert.assertEquals(null, itemException.getMessage());
	}

	@Test
	public void testItemExceptionString() {
		
		String msg = "Error cometido";
		
		ItemException itemException = new ItemException(msg);
		
		Assert.assertEquals(msg, itemException.getMessage());
	}

}
