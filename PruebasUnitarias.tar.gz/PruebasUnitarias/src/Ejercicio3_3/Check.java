package Ejercicio3_3;
public class Check {

	public Check() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		Item[] items = new Item[5];
		
		try{
			items[0] = new MainCourse("Big Pac",true,"./bigpac.jpg",2.69,0.21,365,250);
			items[1] = new Side("Fries",50,"./fries.jpg",1.24,0.21,100,250);
			items[2] = new MainCourse("Uocpper",true,"./uocpper.jpg",2.27,0.21,250,250);
			items[3] = new Beverage("Lemmonade",33,0,true,"./lemmonade.jpg",0.89,0.21,50,250);
			items[4] = new Dessert("Sundae",true,"./sundae.jpg",1.9,0.21,200,250);
			for(Item item : items)
				System.out.println(item);
				
		
		}catch(ItemException ie){
			ie.printStackTrace();
		}
		
	}

}
