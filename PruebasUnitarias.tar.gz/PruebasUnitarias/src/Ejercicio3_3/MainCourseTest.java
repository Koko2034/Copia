package Ejercicio3_3;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class MainCourseTest {

	MainCourse maincourse;
	MainCourse maincourse1;
	
	@Before
	public void inicializate() throws Exception{
		
		maincourse1 = new MainCourse();
		maincourse = new MainCourse("Uocpper",true,"./uocpper.jpg",2.27,0.21,250,250);
		
	}
	
	@Test
	public void testMainCourse() throws Exception {
		
		assertTrue(maincourse1.isHot());
	}

	@Test
	public void testMainCourseStringBooleanStringDoubleDoubleDoubleInt() throws Exception{
		
		assertEquals("Uocpper", maincourse.getName());
		assertEquals("./uocpper.jpg", maincourse.getImageSrc());
		assertEquals(2.27, maincourse.getNetPrice(),1e-15);
		assertEquals(0.21, maincourse.getTax(),1e-15);
		assertEquals(250, maincourse.getKcal(),1e-15);
		assertEquals(250, maincourse.getStock());
		assertTrue(maincourse.isHot());
	}

	@Test
	public void testIsHot() throws Exception{
		
		assertTrue(maincourse.isHot());
	}

	@Test
	public void testSetHot() throws Exception{
		
		maincourse.setHot(false);
		
		assertFalse(maincourse.isHot());
	}

}
