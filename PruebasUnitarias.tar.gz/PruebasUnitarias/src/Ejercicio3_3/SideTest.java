package Ejercicio3_3;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

public class SideTest {

	Side side;
	Side side1;
	
	@Before
	public void inicializate() throws Exception{
		
		side1 = new Side();
		side = new Side("Fries",50,"./fries.jpg",1.24,0.21,100,250);
	}
	@Rule
	public ExpectedException thrown = ExpectedException.none();


	@Test
	public void testSide() throws Exception{
		
		assertEquals(6, side1.getUnits());
	}

	@Test
	public void testSideStringIntStringDoubleDoubleDoubleInt() throws Exception{
		
		assertEquals("Fries", side.getName());
		assertEquals("./fries.jpg", side.getImageSrc());
		assertEquals(1.24, side.getNetPrice(),1e-15);
		assertEquals(0.21, side.getTax(),1e-15);
		assertEquals(100, side.getKcal(),1e-15);
		assertEquals(250, side.getStock());
		assertEquals(50,side.getUnits());
	}

	@Test
	public void testGetUnits() throws Exception{
		
		assertEquals(50,side.getUnits());
	}

	@Test
	public void testSetUnits() throws Exception{
		
		side.setUnits(150);
		
		assertEquals(150, side.getUnits());
		
	}

	@Test
	public void testSetUnitsFail() throws Exception{
		
		thrown.expectMessage("Units cannot be either zero or negative!!");
	    side.setUnits(-10);
		}
}