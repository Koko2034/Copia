package edu.uoc.donalds.model;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/**
 * This class represents an UocDonald's order.
 * 
 * @author David Garc�a Sol�rzano
 * @version 1.0
 * 
 */

public class Order {
	
	private static int id = 0;
	private DiningLocation diningLocation;
	private List<Item> items;
	private boolean isCommitted;
	
	
	/**
	  * Default constructor which sets id++, diningLocation equals to EATIN and set items with 15 positions.
	 *	   
	 */
	public Order() {		
		diningLocation = DiningLocation.EATIN;
		items = new LinkedList<Item>();
	}


	/**
	 * Returns the order's id.
	 * 
	 * @return Order's number/id.
	 */
	public int getId() {
		return id;
	}


	/**
	 * Sets a new value for the Order's id.
	 * 
	 * @param id New value for the private field "id".
	 */
	public void setId(int id) {
		Order.id = id;
	}


	/**
	 * Returns where the customer will eat her order.
	 * 
	 * @return Dining location's value.
	 */
	public DiningLocation getDiningLocation() {
		return diningLocation;
	}


	/**
	 * Sets where the customer will eat her order.
	 * 
	 * @param diningLocation Location/Place where the customer will eat her order.
	 */
	public void setDiningLocation(DiningLocation diningLocation) {
		this.diningLocation = diningLocation;
	}

	
	/**
	 * Increases 1 unit the value of the private field "id".
	 */
	private void increase1Id(){
		setId(getId()+1); //tambien valdria "id++", pero usando el getter y setter se mejora el mantenimiento ante posibles cambios.
	}
	
	/**
	 * Returns the whole list of items.
	 * 
	 * @return The private field "items".
	 */
	public List<Item> getItems() {
		return items;
	}


	/**
	 * Replaces the whole list of items.
	 *	 
	 * @param items New list of items.
	 */
	public void setItems(List<Item> items) {
		this.items = items;
	}
	
	public void addItem(Item item) throws OrderException{
		if(item.isSoldOut()){
			throw new OrderException("The item is sold out!!! You cannot add it to your order!!!");
		}else{
			if(isCommitted()){
				throw new OrderException("The order has already been committed!!! You cannot add an item!!!");
			}else{
				item.increase1ExpectedPurchase();
				items.add(item);			
			}
		}
	}
	
	/**
	 * Removes the item in the position "index" of the list "items".
	 * 
	 * @param index Position where the item we want to remove is.
	 * @throws OrderException is thrown when the order has already been committed.
	 */
	public void removeItem(int index) throws OrderException{		
		if(isCommitted()){
			throw new OrderException("The order has already been committed!!! You cannot remove an item!!!");
		}else{
			items.get(index).decrease1ExpectedPurchase();
			items.remove(index);
		}
	}
	
	/**
	  * This method adds the gross price of all the items of the order together.
	 * 
	 * @return The sum in euros of the gross price of the order's items.  
	 */
	public double getTotalGrossCost(){
		double total = 0;
		
		for(Item item : items){
			//total += (item!=null)?item.getGrossPrice():0;
			total += item.getGrossPrice(); //quitamos la comprobacion de si es null, porque ahora no tiene sentido.
		}
		
		return total;
		
	}
	
	/**
	  * This method adds the net price of all the items of the order together.
	 * 
	 * @return The sum in euros of the net price of the order's items.  
	 */
	public double getTotalNetCost(){
		double total = 0;
		
		for(Item item : items){
			//total += (item!=null)?item.getNetPrice():0;
			total += item.getNetPrice(); //quitamos la comprobacion de si es null, porque ahora no tiene sentido.
		}
		
		return total;
		
	}

	/**
	 * This method adds the difference between the gross price and the net price of all the items of the order together.
	 * 
	 * @return The sum in euros of the taxes of the order's items.  
	 */
	public double getTotalTaxesCost(){
		double total = 0;
		
		for(Item item : items){
			//total += (item!=null)?(item.getGrossPrice()-item.getNetPrice()):0;
			total += item.getGrossPrice()-item.getNetPrice(); //quitamos la comprobacion de si es null, porque ahora no tiene sentido.
		}
		
		return total;
	}
	
	
	/**
	 * This method overrides Object's toString.
	 * 
	 * @return String with the Order's id, the list of the items with the format "name......grosPrice �", and the total gross cost and total taxes cost.
	 */
	@Override
	public String toString(){
		DecimalFormat df = new DecimalFormat("0.00");
		StringBuilder text = new StringBuilder();
			
		text.append("Dining location: "+getDiningLocation()+"");
		text.append("\n__________________________\n");
		
		for(Item item : items){
			text.append("\n"+item); //aprovechamos el m�todo toString de Item que ya devuelve el String en el formato que necesitamos.
			//Adem�s, gracias al uso de una List, ya no hay que comprobar si es null o no
		}
		
		text.append("\n__________________________\n");
			
		text.append("\nTOTAL: "+df.format(getTotalGrossCost())+" �");
		text.append("\nTaxes: "+df.format(getTotalTaxesCost())+" �");
		text.append("\n__________________________\n");
		
		return text.toString();	
	}
	
	
	/**
	 * Returns isCommitted's value.
	 * 
	 * @return isCommitted's value
	 */
	private boolean isCommitted() {
		return isCommitted;
	}


	/**
	 * Sets isCommitted's value.
	 * 
	 * @param isCommitted New value for the private field "isCommitted".
	 */
	private void setCommitted(boolean isCommitted) {
		this.isCommitted = isCommitted;
	}
	
	
	/**
	 * Commits the current order if this has not been committed yet.
	 * 
	 * @throws Exception When the order is empty, or it has already been committed or "decrease1Stock" throws an exception. 
	 */
	public void commit() throws Exception{ //Ponemos Exception porque as� podemos gestionar el lanzamiento de diferentes tipos de Excepcions (i.e. ItemException, OrderException, IOException).
		/*
		 * Tambi�n se podr�a haber hecho:
		 * 
		 * public void commit() throws ItemException, OrderException, IOException{
		 * 
		 * De esta forma no se propagan otros tipos de excepciones que no sean estos 3, p.ej. null pointers, cosa que con Exception s�.
		 */
		if(!isCommitted()){
			if(getItems().size()==0){
				throw new OrderException("Your order is empty, then you cannot commit it!!!");
			}else{
				setCommitted(true);
				increase1Id();
				Iterator<Item> itr = getItems().iterator();
				
				while(itr.hasNext()){
					Item item = itr.next();
					item.decrease1Stock(); //throws ItemException
					item.decrease1ExpectedPurchase(); //tambien se podria haber llamado a item.setExpectedPurchase(0)
				}
				
				printReceipt(); //throws IOException
			}
			
		}else{
			throw new OrderException("The order has already been committed!!!");
		}		
	}
	
	/**
	 * Prints the receipt in a text file called "receipt.txt" located in the "output" folder.
	 * 
	 * @throws IOException When there is a problem with the I/O stream.
	 */
	private void printReceipt() throws IOException{		
		File file = new File("output/receipt.txt");
		FileWriter 	fw = new FileWriter(file);
		PrintWriter pw = new PrintWriter(fw);
		
		pw.println("**UocDonald's**\n");
		pw.println("||No. Order: "+getId()+"||\n\n");
		pw.println(toString());
		pw.close();		
	}
}
