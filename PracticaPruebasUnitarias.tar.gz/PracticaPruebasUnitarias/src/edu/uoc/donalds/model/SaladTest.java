package edu.uoc.donalds.model;

import static org.junit.Assert.*;

import org.junit.Test;

import org.junit.Assert.*;
import org.junit.Before;

public class SaladTest {

	Salad salad;
	Salad salad1;
	
	@Before
	public void inicializate() throws Exception{
		
		salad1 = new Salad();
		salad = new Salad("Mediterranea",true,"./",4,0.21,50,100);
	}
	@Test
	public void testSetHot() throws Exception{
		
		salad1.setHot(false);
		
		assertEquals(false,salad1.isHot());
		
	}

	@Test
	public void testSalad()  throws Exception{

		assertFalse(salad1.isVegan());
		assertFalse(salad1.isHot());
	}

	@Test
	public void testSaladStringBooleanStringDoubleDoubleDoubleInt()  throws Exception{
		
		assertEquals("Mediterranea",salad.getName());
		assertTrue(salad.isVegan());
		assertEquals("./",salad.getImageSrc());
		assertEquals(4.84,salad.getGrossPrice(),1e-15);
		assertEquals(0.21,salad.getTax(),1e-15);
		assertEquals(50,salad.getKcal(),1e-15);
		assertEquals(100,salad.getStock());
		
	}

	@Test
	public void testIsVegan()  throws Exception{
		
		assertEquals(false, salad1.isVegan());
	}

	@Test
	public void testSetVegan()  throws Exception{
		
		salad1.setVegan(true);
		
		assertEquals(true,salad1.isVegan());
		
		salad1.setVegan(false);
		
		assertEquals(false,salad1.isVegan());
		
		
	}

}
