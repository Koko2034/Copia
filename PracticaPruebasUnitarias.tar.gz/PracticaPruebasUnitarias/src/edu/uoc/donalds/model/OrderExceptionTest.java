package edu.uoc.donalds.model;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;



public class OrderExceptionTest {

	
	@Test
	public void testOrderException() {
		
		Exception exception = new Exception();
		
		assertEquals(null, exception.getMessage());
		
		
		
	}

	@Test
	public void testOrderExceptionString() {
		
		String msg ="Error";
		
		Exception exception = new Exception(msg);
		
		assertEquals(msg, exception.getMessage());
	}

}
