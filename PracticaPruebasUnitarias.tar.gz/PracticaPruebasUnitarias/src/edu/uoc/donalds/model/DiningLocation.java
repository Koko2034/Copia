package edu.uoc.donalds.model;


public enum DiningLocation {
	EATIN, TAKEAWAY
}
