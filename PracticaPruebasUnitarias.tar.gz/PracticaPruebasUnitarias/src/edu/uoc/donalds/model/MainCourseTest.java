package edu.uoc.donalds.model;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import static org.mockito.Mockito.*;

public class MainCourseTest {

	MainCourse mockMain;
	
	
	@Before
	public void inicializate() throws Exception{
		
		mockMain = mock(MainCourse.class);
		when(mockMain.getName()).thenReturn("Dummy");
		when(mockMain.getImageSrc()).thenReturn("./");
		when(mockMain.isHot()).thenReturn(true);
		when(mockMain.getStock()).thenReturn(0);
		when(mockMain.getNetPrice()).thenReturn(0.1);
		when(mockMain.getTax()).thenReturn(0.0);
		when(mockMain.getKcal()).thenReturn(0.0);
	}
	

	@Test
	public void testMainCourse() throws Exception{

		assertEquals(true, mockMain.isHot());
		
		
	}

	@Test
	public void testMainCourseStringBooleanStringDoubleDoubleDoubleInt() throws Exception{
		
		
		
		assertEquals("Dummy",mockMain.getName());
		assertEquals("./",mockMain.getImageSrc());
		assertEquals(true,mockMain.isHot());
		assertEquals(0,mockMain.getStock());
		assertEquals(0.1,mockMain.getNetPrice(),1e-15);
		assertEquals(0.0,mockMain.getTax(),1e-15);
		assertEquals(0.0,mockMain.getKcal(),1e-15);

	
	}
	
	@Test
	public void testIsHot() throws Exception{
			
		assertEquals(true,mockMain.isHot());
			
	}

	@Test
	public void testSetHotFalse() throws Exception{
		
		mockMain.setHot(false);
		when(mockMain.isHot()).thenReturn(false);
		boolean hot = mockMain.isHot();
		
		assertEquals(false,hot);
	}
	@Test
	public void testSetHotTrue() throws Exception{
		mockMain.setHot(true);
		
		boolean hot = mockMain.isHot();
		
		assertEquals(true,hot);
	}

}
