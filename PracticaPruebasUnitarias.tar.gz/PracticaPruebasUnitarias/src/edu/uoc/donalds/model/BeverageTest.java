package edu.uoc.donalds.model;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;


public class BeverageTest {

	Beverage beverage;
	Beverage beverage1;
	
	@Before
	public void inicializate() throws Exception{
		
		beverage1 = new Beverage();
		beverage =new Beverage("Lemmonade",33,0,true,"./lemmonade.jpg",0.89,0.21,50,250);
	}
	@Rule
    public ExpectedException thrown = ExpectedException.none();
	
	@Test
	public void testToString() throws ItemException {
		
		String esperado="Lemmonade (33 cl)......1,08 �";
		
		assertEquals(esperado, beverage.toString());
	}

	@Test
	public void testBeverage() throws Exception{
		
		assertEquals(33,beverage1.getCentiliters());
		assertEquals(0,beverage1.getAlcoholVolume(),1e-15);
		assertTrue(beverage1.isFizzy());
	}

	@Test
	public void testBeverageStringIntDoubleBooleanStringDoubleDoubleDoubleInt() throws Exception {
		
		assertEquals("Lemmonade", beverage.getName());
		assertEquals("./lemmonade.jpg", beverage.getImageSrc());
		assertEquals(0.89, beverage.getNetPrice(),1e-15);
		assertEquals(0.21, beverage.getTax(),1e-15);
		assertEquals(50, beverage.getKcal(),1e-15);
		assertEquals(250, beverage.getStock());
		assertEquals(33,beverage.getCentiliters());
		assertEquals(0,beverage.getAlcoholVolume(),1e-15);
		assertTrue(beverage.isFizzy());
	}

	@Test
	public void testGetCentiliters() throws Exception{

		assertEquals(33, beverage.getCentiliters());
	}

	@Test
	public void testSetCentiliters() throws Exception{
	
		beverage.setCentiliters(250);
		
		assertEquals(250, beverage.getCentiliters());
		
	}
	@Test
	public void testSetCentiliterLess() throws Exception{
		
		thrown.expectMessage("Centiliters cannot be either zero or negative!!");
		beverage.setCentiliters(-11);
		
	}

	@Test
	public void testGetAlcoholVolume() throws Exception{

		assertEquals(0, beverage.getAlcoholVolume(),1e-15);
	}

	@Test
	public void testSetAlcoholVolume() throws Exception{
		
		beverage.setAlcoholVolume(250);
		
		assertEquals(250, beverage.getAlcoholVolume(),1e-15);
		
	}
	
	@Test
	public void testSetAlcoholVolumeLess() throws Exception{
		
		thrown.expectMessage("Alcohol by volume cannot be a negative value!!");
		beverage.setAlcoholVolume(-11);
	}

	@Test
	public void testIsFizzy() throws Exception{
		
		assertTrue(beverage.isFizzy());
	}

	@Test
	public void testSetFizzy() throws Exception{
		
		beverage.setFizzy(false);
		
		assertFalse(beverage.isFizzy());
		
		beverage.setFizzy(true);
		
		assertTrue(beverage.isFizzy());
	}

}
