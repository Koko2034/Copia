package edu.uoc.donalds.model;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;



import static org.junit.Assert.*;



public class BurgerTest {

	Burger burger;
	Burger burger1;
	
	@Before
	public void inicializate() throws Exception{
		
		burger = new Burger("Godzilla", false, "./", 4, 0.21, 150, 500);
		burger1 = new Burger();

	}
	@Rule
	
	public ExpectedException thrown = ExpectedException.none();

	@Test
	public void testSetHot() throws Exception{
		
		burger1.setHot(true);
		
		assertTrue(burger1.isHot());
		
	}

	@Test
	public void testBurger() throws Exception{
		
		assertEquals(false,burger1.isGlutenFree());
	}

	@Test
	public void testBurgerStringBooleanStringDoubleDoubleDoubleInt() throws Exception{
		
		assertEquals("Godzilla",burger.getName());
		assertFalse(burger.isGlutenFree());
		assertEquals("./",burger.getImageSrc());
		assertEquals(4.84,burger.getGrossPrice(),1e-15);
		assertEquals(0.21,burger.getTax(),1e-15);
		assertEquals(150,burger.getKcal(),1e-15);
		assertEquals(500,burger.getStock());
	}

	@Test
	public void testIsGlutenFree() throws Exception{
		
		burger.setGlutenFree(true);
		
		assertTrue(burger.isGlutenFree());
	}

	@Test
	public void testSetGlutenFree() throws Exception{
		
		burger.setGlutenFree(false);
		
		assertEquals(false,burger.isGlutenFree());
		
		burger.setGlutenFree(true);
		
		assertEquals(true,burger.isGlutenFree());
	}

}
