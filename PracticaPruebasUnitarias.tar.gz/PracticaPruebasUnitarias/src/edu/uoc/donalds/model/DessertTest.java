package edu.uoc.donalds.model;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class DessertTest {

	Dessert dessert;
	Dessert dessert1;
	
	@Before
	public void inicializate() throws Exception{
		
		dessert1 = new Dessert();
		dessert = new Dessert("Sundae",true,"./sundae.jpg",1.9,0.21,200,250);
	}
	@Test
	public void testDessert() throws Exception{
		
		assertFalse(dessert1.isDiabetic());	
	}
	
	@Test
	public void testDessertStringBooleanStringDoubleDoubleDoubleInt() throws Exception{
		
		assertEquals("Sundae", dessert.getName());
		assertEquals("./sundae.jpg", dessert.getImageSrc());
		assertEquals(1.9, dessert.getNetPrice(),1e-15);
		assertEquals(0.21, dessert.getTax(),1e-15);
		assertEquals(200, dessert.getKcal(),1e-15);
		assertEquals(250, dessert.getStock());
		assertTrue(dessert.isDiabetic());
	}

	@Test
	public void testIsDiabetic() throws Exception{
		
		assertTrue(dessert.isDiabetic());
	}

	@Test
	public void testSetDiabetic() throws Exception{
		
		dessert.setDiabetic(false);
		
		assertFalse(dessert.isDiabetic());

		dessert.setDiabetic(true);
		
		assertTrue(dessert.isDiabetic());
	}

}
