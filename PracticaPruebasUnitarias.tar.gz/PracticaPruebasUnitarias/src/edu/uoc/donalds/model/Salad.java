package edu.uoc.donalds.model;

/**
 * This class represents a salad of the UocDonald's menu.
 * 
 * @author David Garc�a Sol�rzano
 * @version 1.0
 *  
 */
public class Salad extends MainCourse{

	private boolean isVegan;
	
	/**
	 * Default constructor.
	 * Sets isVegan to false.
	 * Sets isHot to false.
	 * 
	 * @throws ItemException When the parent's constructor throws this exception.
	 */
	public Salad() throws ItemException{		
		super();
		setVegan(false);
		setHot(false); //Debemos indicar que es un plato frio, porque por defecto MainCorse lo pone a true (=caliente).
	}
	
	/**
	 * Constructor with arguments.
	 * 
	 * @param name Salad's name.
	 * @param isVegan It is true if the salad is suitable for vegans, otherwise it is false.	
	 * @param imageSrc The source of the main course's image.
	 * @param grossPrice Main course's gross price.
	 * @param tax Main course's tax.
	 * @param kcal Main course's kcal.
	 * @param stock Number of main courses of this type that the restaurant has.
	 * @throws ItemException When some method throws this exception.
	 */
	public Salad(String name, boolean isVegan, String imageSrc, double grossPrice, double tax, double kcal, int stock) throws ItemException{
		super(name,false,imageSrc,grossPrice,tax,kcal,stock);
		setVegan(isVegan);
	}

	/**
	 * Returns the current value of the private field "isVegan".
	 * 
	 * @return true is suitable for vengans, false is not suitable for vegans.
	 */
	public boolean isVegan() {
		return isVegan;
	}

	/**
	 * Replaces the current value of the private field "isVegan".
	 * 
	 * @param isVegan New value for the private field "isVegan".
	 */
	public void setVegan(boolean isVegan) {
		this.isVegan = isVegan;
	}

	@Override
	/**
	 * See setHot method in Burger class.
	 * @param isHot New value for the private field "isHot". It will not be assign it. The field "setHot" will always be "false" for Salad objects.
	 */
	public void setHot(boolean isHot) {
		super.setHot(false);
	}
}
