package edu.uoc.donalds.model;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;




public class OrderTest {

	@Rule
	
	public ExpectedException thrown = ExpectedException.none();
	
	Item mockItem;
	Order order;
	Order mockOrder;
	
	@Before
	
	public void inciar() throws Exception{
		
		mockItem = mock(Item.class);
		order = new Order();
		mockOrder = mock(Order.class);
	}
	/*	Order order;
		
		@Before
		public void iniciar() throws Exception{
			Order order = new  Order();
		}*/
	@Test
	public void testOrder()  throws Exception{
		
		Assert.assertEquals(1,order.getId());
		Assert.assertEquals(DiningLocation.EATIN, order.getDiningLocation());
		Assert.assertEquals(0,order.getItems().size());
	}

	@Test
	public void testGetId()  throws Exception{
		
		order.setId(1);
		
		Assert.assertEquals(1, order.getId());
	}

	@Test
	public void testSetId()  throws Exception{
		
		order.setId(8);
		
		Assert.assertEquals(8,order.getId());
	}

	@Test
	public void testGetDiningLocation() throws Exception{
		
		Assert.assertEquals(DiningLocation.EATIN, order.getDiningLocation());
	}

	@Test
	public void testSetDiningLocation() throws Exception{
	
		order.setDiningLocation(DiningLocation.TAKEAWAY);
		
		Assert.assertEquals(DiningLocation.TAKEAWAY, order.getDiningLocation());

		order.setDiningLocation(DiningLocation.EATIN);
		
		Assert.assertEquals(DiningLocation.EATIN, order.getDiningLocation());
	}

	@Test
	public void testGetItems()  throws Exception{
		
		List<Item> items = new ArrayList<Item>();
		Burger burger = new Burger("Big Pac",true,"./bigpac.jpg",2.69,0.21,365,250);
		items.add(mockItem);
		order.addItem(mockItem);
		
		Assert.assertTrue(order.getItems().equals(items));
	}

	@Test
	public void testSetItems()  throws Exception{
		Order order = new Order();
		List<Item> items = new ArrayList<Item>();
		items.add(mockItem);
		order.addItem(mockItem);
		items.add(mockItem);
		order.setItems(items);
		
		Assert.assertTrue(order.getItems().equals(items));
	}
	@Test
	public void testAddItemSold() throws Exception{
		when(mockItem.isSoldOut()).thenReturn(true);
		
		thrown.expectMessage("The item is sold out!!! You cannot add it to your order!!!");
		order.addItem(mockItem);
		
	}
	@Test
	public void testAddItemCommitted() throws Exception{
		
		when(mockItem.isSoldOut()).thenReturn(true);
	
		thrown.expectMessage("The item is sold out!!! You cannot add it to your order!!!");
		order.addItem(mockItem);
		
	}
	@Test
	public void testAddItem() throws Exception{
		
		when(mockItem.isSoldOut()).thenReturn(false);
		mockItem.increase1ExpectedPurchase();
		int pos = order.getItems().size();
		
		order.addItem(mockItem);
		
		Assert.assertTrue(order.getItems().get(pos).equals(mockItem));
	}

	@Test
	public void testRemoveItem() throws Exception{
		
		
		order.addItem(mockItem);
		int code = order.getItems().get(0).hashCode();
		order.removeItem(0);
		
		boolean control = false;
		
		for(int i=0;i<order.getItems().size();i++){
			control = order.getItems().get(i).hashCode() == code ? true:false;

		}
		
		assertFalse(control);
		
		
		
	}

	@Test
	public void testGetTotalGrossCost()  throws Exception{
		
		double coste =0;
		coste+=mockItem.getGrossPrice();
		coste+=mockItem.getGrossPrice();
		order.addItem(mockItem);
		order.addItem(mockItem);
		
		Assert.assertEquals(coste, order.getTotalGrossCost(),1e-15);
	}

	@Test
	public void testGetTotalNetCost()  throws Exception{
		
		double coste =0;
		coste+=mockItem.getNetPrice();
		coste+=mockItem.getNetPrice();
		order.addItem(mockItem);
		order.addItem(mockItem);
		
		Assert.assertEquals(coste, order.getTotalNetCost(),1e-15);
	}

	@Test
	public void testGetTotalTaxesCost()  throws Exception{
		
		double coste =0;
		coste+=mockItem.getGrossPrice()-mockItem.getNetPrice();
		coste+=mockItem.getGrossPrice()-mockItem.getNetPrice();
		order.addItem(mockItem);
		order.addItem(mockItem);
		
		Assert.assertEquals(coste, order.getTotalTaxesCost(),1e-15);
	}

	@Test
	public void testToString()  throws Exception{
		
		order.addItem(new Burger("Big Pac",true,"./bigpac.jpg",2.69,0.21,365,250));
		String namePrice ="Dining location: EATIN\n" + 
				"__________________________\n" + 
				"\n" + 
				"Big Pac......3,25 �\n" + 
				"__________________________\n" + 
				"\n" + 
				"TOTAL: 3,25 �\n" + 
				"Taxes: 0,56 �\n" + 
				"__________________________\n";
		
		Assert.assertEquals(namePrice, order.toString());
	}
	@Test
	public void testCommitFalse() throws Exception{

		while(order.getItems().size()>0){
			order.removeItem(order.getItems().size()-1);
		}
		thrown.expectMessage("Your order is empty, then you cannot commit it!!!");
		order.commit();
		
	}
	@Test
	public void testCommitTrue() throws Exception{
		
		/*
		thrown.expectMessage("The order has already been committed!!!");
		order.commit();
		*/
	}
	@Test
	public void testCommit()  throws Exception{
		/*
		order.setCommitted(true);
		Burger burguer = new Burger("Big Pac",true,"./bigpac.jpg",2.69,0.21,365,250);
		int stock = burguer.getStock();
		int expPur = burguer.getExpectedPurchase();
		order.commit();
		Assert.assertEquals(stock-1, burguer.getStock());
		Assert.assertEquals(expPur-1, burguer.getExpectedPurchase());*/
		
	}

}
