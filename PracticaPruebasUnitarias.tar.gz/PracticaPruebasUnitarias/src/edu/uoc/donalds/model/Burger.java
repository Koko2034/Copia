package edu.uoc.donalds.model;

/**
 * This class represents a burger of the UocDonald's menu.
 * 
 * @author David Garc�a Sol�rzano
 * @version 1.0
 *  
 */
public class Burger extends MainCourse{

	private boolean isGlutenFree;
	
	/**
	 * Default constructor.
	 * Sets isGlutenFree to false.
	 * 
	 * @throws ItemException When the parent's constructor throws this exception.
	 */
	public Burger() throws ItemException{		
		super();
		setGlutenFree(false);
	}
	
	/**
	 * Constructor with arguments.
	 * 
	 * @param name Burger's name.
	 * @param isGlutenFree It is true if the burger is gluten free, otherwise it is false.	
	 * @param imageSrc The source of the main course's image.
	 * @param grossPrice Main course's gross price.
	 * @param tax Main course's tax.
	 * @param kcal Main course's kcal.
	 * @param stock Number of main courses of this type that the restaurant has.
	 * @throws ItemException When some method throws this exception.
	 */
	public Burger(String name, boolean isGlutenFree, String imageSrc, double grossPrice, double tax, double kcal, int stock) throws ItemException{
		super(name,true,imageSrc,grossPrice,tax,kcal,stock);
		setGlutenFree(isGlutenFree);
	}

	/**
	 * Returns the current value of the private field "isGlutenFree".
	 * 
	 * @return true is suitable for gluten intolerants, false is not suitable for gluten intolerants.
	 */
	public boolean isGlutenFree() {
		return isGlutenFree;
	}

	/**
	 * Replaces the current value of the private field "isGlutenFree".
	 * 
	 * @param isGlutenFree New value for the private field "isGlutenFree".
	 */
	public void setGlutenFree(boolean isGlutenFree) {
		this.isGlutenFree = isGlutenFree;
	}

	@Override
	/**
	 * Overrides the MainCourse's setHot method in order to avoid that someone change the value of the private field "isHot".
	 * We cannot change the access modifier from public to private because such thing is not allowed.
	 * Therefore, regardless of the parameter's value, we will always set "true" to the private field "isHot".
	 * 
	 * Another way to do this is to change the access modifier in MainCourse's setHot. For example:
	 * 
	 * If it is private, then any future subclass that need to set "isHot" field will have to override this method with public access.
	 * If it is protected, similar to the "private" case.
	 * 
	 * @param isHot New value for the private field "isHot". It will not be assign it. The field "setHot" will always be "true" for Burger objects.
	 */
	public void setHot(boolean isHot) {
		super.setHot(true);
	}
}
