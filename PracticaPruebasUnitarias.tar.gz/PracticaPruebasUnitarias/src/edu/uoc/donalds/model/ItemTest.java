package edu.uoc.donalds.model;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;


public class ItemTest {

	Burger item;
	Burger burguer;
	
	
	@Rule
	
	public ExpectedException thrown = ExpectedException.none();
	
	@Before
	
	public void iniciar() throws Exception{
		burguer = new Burger("Godzilla", false, "./", 4, 0.21, 150, 500);
		item = new Burger();
		
	}
	
	
	@Test
	public void testItem() throws Exception{
		
		
		Assert.assertEquals("Dummy", item.getName());
		Assert.assertEquals("./", item.getImageSrc());
		Assert.assertEquals(0.1, item.getNetPrice(),1e-15);
		Assert.assertEquals(0, item.getTax(),1e-15);
		Assert.assertEquals(1, item.getKcal(),1e-15);
		Assert.assertEquals(0, item.getStock());
		
		
	}

	@Test
	public void testItemStringStringDoubleDoubleDoubleInt()throws Exception {
		
		Assert.assertEquals("Godzilla", burguer.getName());
		Assert.assertEquals("./", burguer.getImageSrc());
		Assert.assertEquals(4, burguer.getNetPrice(),1e-15);
		Assert.assertEquals(0.21, burguer.getTax(),1e-15);
		Assert.assertEquals(150, burguer.getKcal(),1e-15);
		Assert.assertEquals(500, burguer.getStock());
		Assert.assertEquals(0,burguer.getExpectedPurchase());
		
	
	}

	@Test
	public void testGetName()throws Exception {
		
		
		String name = item.getName();
		
		Assert.assertEquals(name, "Dummy");
	}

	@Test
	public void testSetName() throws Exception{
		
		String name = "Javier";
		
		item.setName(name);
		
		Assert.assertEquals(name, item.getName());
		
	}
	@Test
	public void testSetNameMore() throws Exception{
		 
		thrown.expectMessage("The name cannot be longer than 15 characters!!");
		item.setName("Manolo Cabeza Bolo");
	}

	@Test
	public void testGetImageSrc()  throws Exception{
		
		Assert.assertEquals(item.getImageSrc(), "./");

	}

	@Test
	public void testSetImageSrc()  throws Exception{
		
		String imageSrc = "./image";
		
		item.setImageSrc(imageSrc);
		
		Assert.assertEquals(imageSrc, item.getImageSrc());
	}

	@Test
	public void testGetNetPrice()  throws Exception{
		
		Assert.assertEquals(item.getNetPrice(), 0.1,1e-15);
	}

	@Test
	public void testSetNetPrice()  throws Exception{
		
		double netPrice = 0.5;
		
		item.setNetPrice(netPrice);
		
		Assert.assertEquals(netPrice, item.getNetPrice(),1e-15);
		
			
	}
	@Test 
	public void testSetNetPriceLess() throws Exception{
		
		thrown.expectMessage("Net price cannot be a negative value!!");
		
	    item.setNetPrice(-11);
	}

	@Test
	public void testGetTax()  throws Exception{
		
		Assert.assertEquals(item.getTax(), 0,1e-15);
	}

	@Test
	public void testSetTax()  throws Exception{
		
		double tax = 0.5;
		
		item.setTax(tax);
		
		Assert.assertEquals(tax, item.getTax(),1e-15);
		
			thrown.expectMessage("Tax cannot be a negative value!!");
		    item.setTax(-11);
	}
	@Test
	public void testSetTaxLess() throws Exception{
		
		thrown.expectMessage("Tax cannot be a negative value!!");
	   
		item.setTax(-11);
	}

	@Test
	public void testGetKcal()  throws Exception{
		
		Assert.assertEquals(item.getKcal(), 1,1e-15);
	}

	@Test
	public void testSetKcal() throws Exception {
		
		
		double kcal = 0.5;
		
		item.setKcal(kcal);
		
		Assert.assertEquals(kcal, item.getKcal(),1e-15);
		
		
		
	}
	@Test
	public void testSetKcalLess() throws Exception{
		
		thrown.expectMessage("Kcal cannot be a negative value!!");
		
		item.setKcal(-11);
		
	}

	@Test
	public void testGetStock() throws Exception {
		
		
		Assert.assertEquals(item.getStock(), 0);
		
	}

	@Test
	public void testSetStock() throws Exception {

		
		int stock = 4;
		
		item.setStock(stock);
		
		Assert.assertEquals(stock, item.getStock());		
		
	}
	@Test
	public void testSetStockLess() throws Exception{
		
		thrown.expectMessage("Stock cannot be a negative value!!");
		
		item.setStock(-11);
	}
	@Test
	public void testDecrease1StockSucess() throws Exception{
		
		int units = 100;
		item.setStock(units);
		
		item.decrease1Stock();
		
		Assert.assertEquals(units-1, item.getStock());
	}
	@Test
	public void testDecrease1Stock()  throws Exception{
		
		thrown.expectMessage("This item is sold out!! You cannot decrease 1 unit.");
		item.decrease1Stock();
	}

	@Test
	public void testGetGrossPrice()  throws Exception{
		
		Assert.assertEquals(item.getGrossPrice(),0.1,1e-15);
		
		item.setTax(2);
		double netPrice = ( item.getTax()*item.getNetPrice())+item.getNetPrice();
		
		Assert.assertEquals(item.getGrossPrice(),netPrice ,1e-15);
	}

	@Test
	public void testToString()  throws Exception{
		
		String name_price ="Dummy......0,10 �";
		
		Assert.assertEquals(name_price, item.toString());
		
	}

	@Test
	public void testGetExpectedPurchase() throws Exception{
		
		Assert.assertEquals(item.getExpectedPurchase(), 0);
	}

	@Test
	public void testSetExpectedPurchase() throws Exception{
		
		int expPur = 4;
		
		item.setExpectedPurchase(expPur);
		
		Assert.assertEquals(expPur, item.getExpectedPurchase());
	}

	@Test
	public void testIncrease1ExpectedPurchase() throws Exception{
		
		item.setExpectedPurchase(5);
		
		item.increase1ExpectedPurchase();
		
		Assert.assertEquals(6,item.getExpectedPurchase());
	}

	@Test
	public void testDecrease1ExpectedPurchase() throws Exception{
		
		item.setExpectedPurchase(5);
		
		item.decrease1ExpectedPurchase();
		
		Assert.assertEquals(4,item.getExpectedPurchase());
	}

	@Test
	public void testIsSoldOutcero() throws Exception{
		
		item.setStock(0);
		
		Assert.assertTrue(item.isSoldOut());
	}
	@Test
	public void testIsSoldOutOutStock() throws Exception{
		
		item.setStock(5);
		
		item.setExpectedPurchase(5);
		
		Assert.assertTrue(item.isSoldOut());
	}
	@Test
	public void testIsSoldOut() throws Exception{
		
		item.setStock(5);
		
		item.setExpectedPurchase(4);
		
		Assert.assertFalse(item.isSoldOut());
	}

}
