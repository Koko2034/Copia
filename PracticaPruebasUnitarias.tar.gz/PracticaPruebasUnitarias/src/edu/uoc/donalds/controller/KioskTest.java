package edu.uoc.donalds.controller;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import edu.uoc.donalds.model.*;
import edu.uoc.donalds.utils.Inventory;
import org.mockito.Mockito;

import static org.mockito.Mockito.*;

import java.util.LinkedList;
import java.util.List;


public class KioskTest {

	Kiosk kiosk;
	Order order;
	Item mockItem;
	
	@Before
	public void inicialize() throws Exception{
		
		mockItem = mock(Item.class);
		kiosk = new Kiosk();
		order = new Order();
		
		when(mockItem.getName()).thenReturn("Dummy");
		when(mockItem.getImageSrc()).thenReturn("./");
		when(mockItem.getNetPrice()).thenReturn(0.1);
		when(mockItem.getTax()).thenReturn(0.0);
		when(mockItem.getKcal()).thenReturn(1.0);
		when(mockItem.getStock()).thenReturn(0);
			
	}
	
	@Rule
	
	public ExpectedException thrown = ExpectedException.none();

	@Test
	public void testKiosk() {

		String ruta ="";
		
		Inventory inventory = new Inventory();
		
		assertTrue(ruta.isEmpty());
	}

	@Test
	public void testKioskString() {
		
		String ruta ="";
		
		Inventory inventory = new Inventory();
		
		assertTrue(ruta.isEmpty());
	}
	@Test
	public void testKioskStringString() throws Exception{
		
	/*	String ruta ="./archivos/";
		
		Inventory inventory = new Inventory(ruta);
		
		assertFalse(ruta.isEmpty());
		*/
	}

	@Test
	public void testCreateOrder() {
		
		kiosk.createOrder();
		
		Assert.assertEquals(0,this.order.getId());//TENGO DUDAS AL RESPEECTO
		Assert.assertEquals(DiningLocation.EATIN, this.order.getDiningLocation());
		Assert.assertEquals(0,kiosk.getItemsOrder().size());
	}

	@Test
	public void testSetDiningLocation() {
		
		// cREO QUE DEBO HACERLO CON KIOSK..... PERO CLARO NO ESTA EL METODO GET Y SI EL SET
	
		kiosk.createOrder();
			
		this.order.setDiningLocation(DiningLocation.TAKEAWAY);
		
		assertEquals(DiningLocation.TAKEAWAY,this.order.getDiningLocation());
		
		this.order.setDiningLocation(DiningLocation.EATIN);
		
		assertEquals(DiningLocation.EATIN,this.order.getDiningLocation());
	}

	@Test
	public void testAddItem2Order() throws Exception {
		
		kiosk.createOrder();
		int pos=kiosk.getItemsOrder().size();
		
		kiosk.addItem2Order(mockItem);
		
		Assert.assertEquals(mockItem, kiosk.getItemsOrder().get(pos));
		
	}

	@Test
	public void testRemoveItemFromOrder() throws Exception{
	
		kiosk.createOrder();
		int pos = 0;
		kiosk.addItem2Order(mockItem);
		
		int code = kiosk.getItemsOrder().get(pos) .hashCode();
		boolean control = false;
		
		kiosk.removeItemFromOrder(pos);
		for(int i=0;i<kiosk.getItemsOrder().size();i++){
			
			control = kiosk.getItemsOrder().get(i).hashCode() == code ? true:false;
		}
		
		Assert.assertFalse(control);
		
	}

	@Test
	public void testGetItemsOrder() {
		
		
		// Otro medodo con dudas
		
		
		kiosk.createOrder();
		List<Item> items = new LinkedList<Item>();
		items.add(mockItem);
		items.add(mockItem);
		this.order.setItems(items);
		
		Assert.assertEquals(items, this.order.getItems());
	}

	@Test
	public void testShowOrder() {
		
	}

	@Test
	public void testGetOrderTotalGrossCost() throws Exception{
		
		when(mockItem.getGrossPrice()).thenReturn(4.0);
		
		kiosk.createOrder();
		
		double coste =0;
		coste+=mockItem.getGrossPrice();
		coste+=mockItem.getGrossPrice();
		kiosk.addItem2Order(mockItem);
		kiosk.addItem2Order(mockItem);
		
	
		Assert.assertEquals(coste, kiosk.getOrderTotalGrossCost(),1e-15);
		
	}

	@Test
	public void testCommitOrder() {
		
	}

	@Test
	public void testGetInventoryPerCategory() {
		
	}

}
