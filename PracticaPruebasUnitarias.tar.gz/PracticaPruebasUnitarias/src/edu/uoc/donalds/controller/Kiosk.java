package edu.uoc.donalds.controller;


import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import edu.uoc.donalds.model.*;
import edu.uoc.donalds.utils.Inventory;

/**
 * This class represents a kiosk (entry point class).
 * 
 * @author David Garc�a Sol�rzano
 * @version 1.0
 *  
 */
public class Kiosk {
	
	private Order order;
	private Inventory inventory;
	
	/**
	 * Constructor.
	 */
	public Kiosk() {
		this("");
	}
	
	
	/**
	 * Constructor with one argument.
	 * @param fileNameInventory Path to the file that contains inventory's data.
	 */
	public Kiosk(String fileNameInventory){
		if(fileNameInventory.isEmpty()){
			inventory = new Inventory(); //We cannot use "this();", because a constructor call must be the first statement in a constructor
		}else{
			inventory = new Inventory(fileNameInventory);
		}
	}
	
	
	/**
	 * Creates a new order object.
	 */
	public void createOrder(){
		order = new Order();
	}
	
	/**
	 * Sets the dining location for the current order.
	 * @param diningLocation an enum with the value "EATIN" or "TAKEAWAY"
	 */
	public void setDiningLocation(DiningLocation diningLocation){
		order.setDiningLocation(diningLocation);
	}

	/**
	 * Sets a new item
	 * @param item New item to add to the order.
	 * @throws OrderException is thrown when the item to add is sold out or the order is committed.
	 */
	public void addItem2Order(Item item) throws OrderException{
		order.addItem(item);
	}
	
	/**
	 * Removes the item in the position "index" from the order.
	 * @param index Position of the item to remove.
	 * @throws OrderException When the index is out of the bounds of the list or the order is committed.
	 */
	public void removeItemFromOrder(int index) throws OrderException{
		order.removeItem(index);	
	}
	
	/**
	 * Returns a list which includes the items added to the current order
	 * @return List with Order's items.
	 */
	public List<Item> getItemsOrder(){
		return order.getItems();	
	}
	
	/**
	 * Returns a list which includes the items added to the current order
	 * @return List with Order's items.
	 */
	public String showOrder(){
		StringBuilder text = new StringBuilder();
		text.append("\n*********This is your order***********\n");
		text.append(order);
		return text.toString();
	}
	
	/**
	 * Returns the total gross cost of the current order
	 * @return Gross cost of the order.
	 */
	public double getOrderTotalGrossCost(){
		return order.getTotalGrossCost();
	}
	
	/**
	 * Commit the current order
	 * @throws Exception When the order has already been committed or decrease1Stock throws an ItemException.
	 */
	public void commitOrder() throws Exception{
		order.commit();
	}
	
	
	/**
	 * Returns a List sorted by item's name (first numbers, after characters, etc.) with those items from the inventory that match the category indicated.
	 * If the category does not match with "MAINCOURSE", "SIDE", "BEVERAGE" or "DESSERT", then this method returns the whole inventory list sorted by name.  
	 *
	 * Note: We recommend using Java 8's lambda expressions to do this method. However, using lamda expressions is not mandatory.
	 * See: https://dzone.com/articles/using-lambda-expression-sort
	 *
	 *@param category Item's category. The available categories are: "MAINCOURSE", "SIDE", "BEVERAGE" and "DESSERT".
	 *@return List with Order's items sorted by name and filtered by category.
	 */
	public List<Item> getInventoryPerCategory(String category){
		Stream<Item> s = null;
		List<Item> list = inventory.getList();
		Collections.sort(list, (i1,i2) -> i1.getName().compareTo(i2.getName()));		
		
		switch(category.toUpperCase()){
			case "MAINCOURSE":
				s = list.stream().filter(p-> p instanceof MainCourse);
				break;
			
			case "SIDE":
				s = list.stream().filter(p-> p instanceof Side);
				break;
				
			case "BEVERAGE":
				s = list.stream().filter(p-> p instanceof Beverage);
				break;
				
			case "DESSERT":
				s = list.stream().filter(p-> p instanceof Dessert);
				break;
				
			default:
				s = list.stream();
		}
				
		return	s.collect(Collectors.toList());	
	}	
}
