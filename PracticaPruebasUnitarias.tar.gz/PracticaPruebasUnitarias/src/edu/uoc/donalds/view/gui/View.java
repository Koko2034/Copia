package edu.uoc.donalds.view.gui;

public enum View {
	WELCOME,DINING_LOCATION,MENU,MAINS,SIDES,BEVERAGES,DESSERTS
}
